from __future__ import print_function
# This file makes this directory into a package.
# it exists to test 'python -m gevent.monkey monkey_package'
print(__file__)
print(__name__)
